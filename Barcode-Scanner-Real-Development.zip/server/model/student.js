const express = require('express')
const services = require('../controller/services')
const multer  = require('multer')
const path    = require('path')
const student = express.Router()

// ── Message file upload (100 MB limit) ──────────────────────
const msgStorage = multer.diskStorage({
    destination: (req, file, cb) => {
        const dir = path.join(__dirname, '../../uploads/message_files/')
        require('fs').mkdirSync(dir, { recursive: true })
        cb(null, dir)
    },
    filename: (req, file, cb) => {
        const ext  = path.extname(file.originalname)
        const base = path.basename(file.originalname, ext).replace(/[^a-zA-Z0-9_-]/g, '_').substring(0, 50)
        cb(null, `msg_${Date.now()}_${base}${ext}`)
    }
})
const uploadMsgFile = multer({
    storage: msgStorage,
    limits: { fileSize: 100 * 1024 * 1024 } // 100 MB
})


student.use(express.json())

// ============================================================
// MULTER — Student Profile Picture Upload
// ============================================================
const studentPicStorage = multer.diskStorage({
    destination: (req, file, cb) => cb(null, path.join(__dirname, '../../uploads/profile_pictures/')),
    filename:    (req, file, cb) => {
        const unique = Date.now() + '-' + Math.round(Math.random() * 1e6)
        cb(null, 'student-' + unique + path.extname(file.originalname))
    }
})
const uploadStudentPic = multer({
    storage: studentPicStorage,
    limits: { fileSize: 5 * 1024 * 1024 },
    fileFilter: (req, file, cb) => {
        const allowed = /jpeg|jpg|png|webp/
        const valid   = allowed.test(path.extname(file.originalname).toLowerCase())
                     && allowed.test(file.mimetype)
        valid ? cb(null, true) : cb(new Error('Only JPEG, PNG, or WEBP images are allowed.'))
    }
})

// Get Student Data's
student.get('/student_get_data', async (req, res) => {
    try {
        const token = services.removeBearer(req.headers['authorization'])
        const decodedToken = services.verifyToken(token)
        const data = await services.getStudentsData(decodedToken.student_id)
        res.json({ ok: true, message: 'Successfully retrieved data!', contents: data })
    } catch(err) {
        res.status(401).json({ ok: false, message: err })
    }
})

// Update Student Data
student.put('/student_update_profile', async (req, res) => {
    try {
        const token = services.removeBearer(req.headers['authorization']);
        const decodedToken = services.verifyToken(token);
        if (!decodedToken) return res.status(401).json({ message: 'Unauthorized' });

        const studentId = decodedToken.student_id;

        const result = await services.studentUpdateProfile(studentId, req.body);

        if (result.duplicate) {
            return res.status(409).json({ ok: false, duplicate: true, message: `ID number "${req.body.idNumber}" is already assigned to another student.` });
        }

        const fullName = `${decodedToken.student_firstname} ${decodedToken.student_lastname}`
        services.writeActivityLog(decodedToken.student_id, fullName, 'student', 'UPDATE_PROFILE', 'Student', null, fullName, `Updated profile — ID No: ${req.body.idNumber || decodedToken.student_id_number}`, req.ip, req.body?.device_info || req.headers['x-device-info'] || req.headers['user-agent'])
        res.json({ ok: true, message: 'Profile updated successfully' });

    } catch (error) {
        console.error('Update profile error:', error);
        res.status(500).json({ ok: false, message: error.message || 'Server error' });
    }
})

// Change Student password
student.put('/student_change_password', async (req, res) => {
    try {
        const { currentPassword, newPassword } = req.body
        const token = services.removeBearer(req.headers['authorization'])
        const decodedToken = services.verifyToken(token)
        const result = await services.updateStudentPassword(currentPassword, newPassword, decodedToken.student_id)
        const fullName = `${decodedToken.student_firstname} ${decodedToken.student_lastname}`
        services.writeActivityLog(decodedToken.student_id, fullName, 'student', 'CHANGE_PASSWORD', 'Student', null, fullName, 'Student changed their password', req.ip, req.body?.device_info || req.headers['x-device-info'] || req.headers['user-agent'])
        res.json({ ok: true, message: result })
    } catch(err) {
        res.status(401).json({ ok: false, message: err })
    }
})

// Get student barcode
student.get('/student_barcode', async (req, res) => {
    try {
        const token = services.removeBearer(req.headers['authorization'])
        const decodedToken = services.verifyToken(token)
        const result = await services.getStudentBarcode(decodedToken.student_id)
        res.json({ ok: true, message: 'Successfully retrieved barcode',  content: result})
    } catch(err) {
        res.status(401).json({ ok: false, message: err })
    }
})

// Update student barcode
student.put('/update_student_barcode', async (req, res) => {
    try {
        const { barcode, teacher_serial } = req.body  // teacher_serial binds barcode to specific class
        const token = services.removeBearer(req.headers['authorization'])
        const decodedToken = services.verifyToken(token)
        const result = await services.updateStudentBarcode(decodedToken.student_id, barcode, teacher_serial || null)
        const fullName = `${decodedToken.student_firstname} ${decodedToken.student_lastname}`
        services.writeActivityLog(decodedToken.student_id, fullName, 'student', 'REGENERATE_BARCODE', 'Student', null, fullName, `Regenerated barcode — ID No: ${decodedToken.student_id_number}`, req.ip, req.body?.device_info || req.headers['x-device-info'] || req.headers['user-agent'])
        res.json({ ok: true, message: result })
    } catch(err) {
        res.status(500).json({ ok: false, message: err })
    }
})

// Get Student Data
student.get('/get_attendance_history_record', async (req, res) => {
    try {
        const token        = services.removeBearer(req.headers['authorization'])
        const decodedToken = services.verifyToken(token)

        if (!decodedToken) return res.status(401).json({ ok: false, message: 'Invalid or expired token.' })

        // Use student_id (numeric PK) — fallback to student_id_number if needed
        const studentId       = decodedToken.student_id
        const studentIdNumber = decodedToken.student_id_number

        if (!studentId && !studentIdNumber) {
            return res.status(401).json({ ok: false, message: 'Could not identify student from token.' })
        }

        const result = await services.getAttendanceHistoryForStudentOnly(studentId, studentIdNumber)
        res.json({ ok: true, message: 'Successfully retrieved student history attendance!', content: result })
    } catch(err) {
        res.status(500).json({ ok: false, message: err.message || String(err) })
    }
})


// Verify student location against their SPECIFIC teacher's set location
// teacher_serial must be passed from the frontend so we check the right teacher,
// preventing a student from bypassing location check via a different enrolled teacher.
student.post('/verify_location', async (req, res) => {
    const { latitude, longitude, teacher_serial } = req.body

    if (latitude === undefined || longitude === undefined) {
        return res.status(400).json({ ok: false, message: 'latitude and longitude are required.' })
    }

    try {
        const token = services.removeBearer(req.headers['authorization'])
        const decodedToken = services.verifyToken(token)

        const result = await services.verifyStudentLocation(
            decodedToken.student_id_number,
            parseFloat(latitude),
            parseFloat(longitude),
            teacher_serial || null  // pass specific teacher serial to prevent bypass
        )

        if (!result.withinRange) {
            return res.json({
                ok: false,
                withinRange: false,
                message: `You are ${result.distance}m away. Must be within ${result.radius}m to generate a barcode.`,
                distance: result.distance,
                radius: result.radius
            })
        }

        res.json({
            ok: true,
            withinRange: true,
            message: `You are within range (${result.distance}m away).`,
            distance: result.distance,
            radius: result.radius
        })

    } catch (err) {
        res.status(500).json({ ok: false, message: err.message || err })
    }
})


// ============================================================
// STUDENT FORGOT PASSWORD — public routes (no token required)
// ============================================================
student.post('/forgot_password/request_otp', async (req, res) => {
    const { email } = req.body
    if (!email) return res.status(400).json({ ok: false, message: 'Email is required.' })
    try {
        await services.sendStudentPasswordResetOTP(email)
        res.json({ ok: true, message: 'OTP sent to your email.' })
    } catch (err) {
        res.status(400).json({ ok: false, message: err.message })
    }
})

student.post('/forgot_password/verify_otp', (req, res) => {
    const { email, otp } = req.body
    if (!email || !otp) return res.status(400).json({ ok: false, message: 'Email and OTP are required.' })
    try {
        services.verifyStudentPasswordResetOTP(email, otp)
        res.json({ ok: true, message: 'OTP verified.' })
    } catch (err) {
        res.status(400).json({ ok: false, message: err.message })
    }
})

student.post('/forgot_password/reset_password', async (req, res) => {
    const { email, new_password, confirm_password } = req.body
    if (!email || !new_password || !confirm_password) return res.status(400).json({ ok: false, message: 'All fields are required.' })
    if (new_password !== confirm_password) return res.status(400).json({ ok: false, message: 'Passwords do not match.' })
    if (new_password.length < 8) return res.status(400).json({ ok: false, message: 'Password must be at least 8 characters.' })
    try {
        await services.resetStudentPasswordWithOTP(email, new_password)
        res.json({ ok: true, message: 'Password reset successfully.' })
    } catch (err) {
        res.status(400).json({ ok: false, message: err.message })
    }
})

// Get Year Levels (public — no token required, used on registration page)
student.get('/year_levels', async (req, res) => {
    try {
        const result = await services.getYearLevels();
        res.json({ ok: true, message: 'Successfully retrieved year levels!', content: result })
    } catch(err) {
        res.status(500).json({ ok: false, message: err.message || String(err) })
    }
})

// Get Programs (public — no token required, used on registration page)
student.get('/programs', async (req, res) => {
    try {
        const result = await services.getAllPrograms()
        res.json({ ok: true, message: 'Successfully retrieved programs!', content: result })
    } catch(err) {
        res.status(500).json({ ok: false, message: err.message || String(err) })
    }
})

// Get all teachers this student is enrolled under (for class picker)
student.get('/enrolled_teachers', async (req, res) => {
    try {
        const token = services.removeBearer(req.headers['authorization'])
        const decodedToken = services.verifyToken(token)
        const result = await services.getStudentEnrolledTeachers(decodedToken.student_id_number)
        res.json({ ok: true, content: result })
    } catch (err) {
        res.status(500).json({ ok: false, message: err.message || err })
    }
})


// Logout
student.post('/logout', async (req, res) => {
    try {
        const token = services.removeBearer(req.headers['authorization']);
        const decoded = services.verifyToken(token);
        if (decoded) services.writeLogoutLog(decoded.student_id, `${decoded.student_firstname} ${decoded.student_lastname}`, decoded.student_email, 'student', req.ip, req.body?.device_info || req.headers['x-device-info'] || req.headers['user-agent']);
        res.json({ ok: true });
    } catch (_) { res.json({ ok: true }); }
})


// Upload Student Profile Picture
student.post('/upload_profile_picture', uploadStudentPic.single('student_profile_picture'), async (req, res) => {
    if (!req.file) return res.status(400).json({ ok: false, message: 'No file uploaded.' })
    try {
        const token       = services.removeBearer(req.headers['authorization'])
        const decoded     = services.verifyToken(token)
        const filename    = await services.updateStudentProfilePicture(decoded.student_id, req.file.filename)
        res.json({ ok: true, message: 'Profile picture updated!', filename })
    } catch (err) {
        res.status(500).json({ ok: false, message: err.message || err })
    }
})

module.exports = student
// ── Messaging ──────────────────────────────────────────────
student.get('/messages/contacts', async (req, res) => {
    try {
        const tok = services.verifyToken(services.removeBearer(req.headers['authorization']))
        if (!tok) return res.status(401).json({ ok: false })
        const contacts = await services.getMessageContacts(tok.student_id, 'student')
        const unread   = await services.getUnreadMessageCount(tok.student_id, 'student')
        res.json({ ok: true, contacts, unread })
    } catch (err) { res.status(500).json({ ok: false, message: err.message }) }
})

student.get('/messages/conversation', async (req, res) => {
    try {
        const tok = services.verifyToken(services.removeBearer(req.headers['authorization']))
        if (!tok) return res.status(401).json({ ok: false })
        const { contact_id, contact_role } = req.query
        await services.markMessagesRead(tok.student_id, 'student', parseInt(contact_id), contact_role)
        const messages = await services.getConversation(tok.student_id, 'student', parseInt(contact_id), contact_role, 100)
        res.json({ ok: true, messages })
    } catch (err) { res.status(500).json({ ok: false, message: err.message }) }
})

student.post('/messages/send', uploadMsgFile.single('file'), async (req, res) => {
    try {
        const tok = services.verifyToken(services.removeBearer(req.headers['authorization']))
        if (!tok) return res.status(401).json({ ok: false })
        const { receiver_id, receiver_role, receiver_name, content } = req.body
        if (!content?.trim() && !req.file) return res.status(400).json({ ok: false, message: 'Message cannot be empty.' })
        const senderName = tok.student_firstname || 'student'
        const fileUrl  = req.file ? `/api/v1/uploads/message_files/${req.file.filename}` : null
        const fileName = req.file ? req.file.originalname : null
        const fileType = req.file ? req.file.mimetype : null
        // Fetch profile pictures for sender and receiver
        const getSenderPic = () => new Promise(r => {
            const picMap = { student:'student_profile_picture FROM student_accounts WHERE student_id', teacher:'teacher_profile_picture FROM teacher WHERE teacher_id', admin:'admin_profile_picture FROM admin_accounts WHERE admin_id', super_admin:'super_admin_profile_picture FROM super_admin_accounts WHERE super_admin_id', guard:null }
            const col = picMap['student']
            if (!col) return r(null)
            require('../configuration/db').execute(`SELECT ${col} = ? LIMIT 1`, [tok.student_id], (e,rows) => r(rows?.[0]?.[Object.keys(rows[0])[0]] || null))
        })
        const getReceiverPic = () => new Promise(r => {
            const picCols = { student:'student_profile_picture FROM student_accounts WHERE student_id', teacher:'teacher_profile_picture FROM teacher WHERE teacher_id', admin:'admin_profile_picture FROM admin_accounts WHERE admin_id', super_admin:'super_admin_profile_picture FROM super_admin_accounts WHERE super_admin_id', guard:null }
            const col = picCols[receiver_role]
            if (!col) return r(null)
            require('../configuration/db').execute(`SELECT ${col} = ? LIMIT 1`, [receiver_id], (e,rows) => r(rows?.[0]?.[Object.keys(rows[0])[0]] || null))
        })
        const [senderPic, receiverPic] = await Promise.all([getSenderPic(), getReceiverPic()])
        const id = await services.sendMessage(tok.student_id, 'student', senderName, receiver_id, receiver_role, receiver_name, content?.trim() || null, fileUrl, fileName, fileType, senderPic, receiverPic)
        res.json({ ok: true, id })
    } catch (err) { res.status(500).json({ ok: false, message: err.message }) }
})

student.get('/messages/search', async (req, res) => {
    try {
        const tok = services.verifyToken(services.removeBearer(req.headers['authorization']))
        if (!tok) return res.status(401).json({ ok: false })
        const users = await services.searchUsersForMessaging(req.query.q || '', tok.student_id, 'student')
        res.json({ ok: true, users })
    } catch (err) { res.status(500).json({ ok: false, message: err.message }) }
})

// ── Message actions ──────────────────────────────────────────
student.delete('/messages/delete-for-me/:id', async (req, res) => {
    try {
        const tok = services.verifyToken(services.removeBearer(req.headers['authorization']))
        if (!tok) return res.status(401).json({ ok: false })
        await services.deleteMessageForMe(parseInt(req.params.id), tok.student_id, 'student')
        res.json({ ok: true })
    } catch (err) { res.status(500).json({ ok: false, message: err.message }) }
})

student.delete('/messages/unsend/:id', async (req, res) => {
    try {
        const tok = services.verifyToken(services.removeBearer(req.headers['authorization']))
        if (!tok) return res.status(401).json({ ok: false })
        await services.unsendMessage(parseInt(req.params.id), tok.student_id, 'student')
        res.json({ ok: true })
    } catch (err) { res.status(500).json({ ok: false, message: err.message }) }
})

student.post('/messages/pin/:id', async (req, res) => {
    try {
        const tok = services.verifyToken(services.removeBearer(req.headers['authorization']))
        if (!tok) return res.status(401).json({ ok: false })
        const msg = await services.pinMessage(parseInt(req.params.id), tok.student_id, 'student')
        res.json({ ok: true, message: msg })
    } catch (err) { res.status(500).json({ ok: false, message: err.message }) }
})

student.put('/messages/edit/:id', async (req, res) => {
    try {
        const tok = services.verifyToken(services.removeBearer(req.headers['authorization']))
        if (!tok) return res.status(401).json({ ok: false })
        const { content } = req.body
        await services.editMessage(parseInt(req.params.id), tok.student_id, 'student', content)
        res.json({ ok: true })
    } catch (err) { res.status(500).json({ ok: false, message: err.message }) }
})